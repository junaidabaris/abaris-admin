export const footerData = {
    
} 