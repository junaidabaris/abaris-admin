import ViewAllBrand from "../../components/home/viewAll/ViewAllBrand"

function ViewAllBrandPage() {
    return <>
        <ViewAllBrand />
    </>
}
export default ViewAllBrandPage