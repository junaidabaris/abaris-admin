import React, { useState } from "react";
import ProductDetail from "../../components/home/product-detail/ProductDetail";

function ProductDetailPage() {

  return (
    <>    
        <ProductDetail />
        
    </>
  );
}

export default ProductDetailPage;
