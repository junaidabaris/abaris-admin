import React from 'react';
import Home from '../../components/home/Home';

function HomePage() {
  return (
    <><Home /></>
  )
}

export default HomePage