import DigitalProducts from "../../Components/digitalProducts/DigitalProducts"

function DigitalProductsPage(){
  return(
    <>
      <DigitalProducts/>
    </>
  )
}
export default DigitalProductsPage