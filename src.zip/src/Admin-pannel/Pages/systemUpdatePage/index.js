import SystemUpdate from "../../Components/systemUpdate/SystemUpdate";

function SystemUpdatePage() {
  return (
    <>
      <SystemUpdate />
    </>
  )
}
export default SystemUpdatePage;