import PickUpPointOrder from "../../Components/pickUpPointOrders/PickUpPointOrders"

function PickUpPointOrderPage() {
    return (
        <>
        <PickUpPointOrder/>
        </>
    )
}
export default PickUpPointOrderPage