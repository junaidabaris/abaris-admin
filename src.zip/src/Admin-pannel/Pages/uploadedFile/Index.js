import UploadedFile from "../../Components/uploadedFile/UploadedFile"

function UploadedFilePages() {
    return (
        <>
        <UploadedFile/>
        </>
    )
}
export default UploadedFilePages