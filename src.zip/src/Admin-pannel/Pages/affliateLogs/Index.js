import AffiliateLogs from "../../Components/affiliateLogs/AffliateLogs"

function AffliateLogsPage() {
    return (
        <>
        <AffiliateLogs/>
        </>
    )
}
export default AffliateLogsPage