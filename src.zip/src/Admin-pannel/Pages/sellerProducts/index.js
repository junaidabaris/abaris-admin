import SellerProductsAdmin from "../../Components/sellerProductsAdmin/SellerProductsAdmin";

function SellerProductsPage() {
    return (
        <>
            <SellerProductsAdmin />
        </>
    )
}
export default SellerProductsPage;