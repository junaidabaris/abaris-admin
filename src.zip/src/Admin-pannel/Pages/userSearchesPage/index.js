import UserSearches from "../../Components/userSearches/UserSearches";

function UserSearchesPage() {
    return (
        <>
            <UserSearches />
        </>
    )
}
export default UserSearchesPage;