import SellerPackage from "../../Components/sellerPackage/SellerPackage"

function SellerPackagePage() {
    return (
        <>
        <SellerPackage/>
        </>
    )
}
export default SellerPackagePage