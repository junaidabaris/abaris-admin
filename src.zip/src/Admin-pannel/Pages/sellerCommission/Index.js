import SellerCommission from "../../Components/sellerCommission/SellerCommission"

function SellerCommissionPage() {
    return (
        <>
        <SellerCommission/>
        </>
    )
}
export default SellerCommissionPage