import AffiliateUsersDetails from "../../Components/affiliateUserDetails/AffiliateUsersDetails"

function AffiliateUserDetailsPage() {
    return (
        <>
        <AffiliateUsersDetails/>
        </>
    )
}
export default AffiliateUserDetailsPage