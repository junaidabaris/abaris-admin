import UserPoints from "../../Components/userPoint/UserPoint"

function UserPointPage() {
    return (
        <>
        <UserPoints/>
        </>
    )
}
export default UserPointPage