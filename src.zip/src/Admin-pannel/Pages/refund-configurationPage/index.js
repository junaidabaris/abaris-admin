import RefundConfiguration from "../../Components/refund-configuration/RefundConfiguration";

function RefundConfigurationPage() {
  return (
    <>
      <RefundConfiguration/>
    </>
  )
}
export default RefundConfigurationPage;