import OrderConfiguration from "../../../Components/setup&Configuration/orderConfiguration/OrderConfiguration"

function OrderConfigurationPage() {
    return (
        <>
            <OrderConfiguration />
        </>
    )
}
export default OrderConfigurationPage