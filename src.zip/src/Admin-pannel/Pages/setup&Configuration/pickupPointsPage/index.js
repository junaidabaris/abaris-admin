import PickupPoints from "../../../Components/setup&Configuration/pickupPoints/PickupPoints"

function PickupPointsPage(){
  return(
    <>
      <PickupPoints/>
    </>
  )
}
export default PickupPointsPage