import GeneralSetting from "../../../Components/setting&Configuration/generalSetting/GeneralSetting";

function GeneralSettingPage() {
    return (
        <>
            <GeneralSetting />
        </>
    )
}
export default GeneralSettingPage;