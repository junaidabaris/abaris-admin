import React from 'react'
import Shippingstates from '../../../../Components/setup&Configuration/shipping/shippingStates/Shippingstates'

function ShippingStatePage() {
    return (
        <Shippingstates />
    )
}

export default ShippingStatePage