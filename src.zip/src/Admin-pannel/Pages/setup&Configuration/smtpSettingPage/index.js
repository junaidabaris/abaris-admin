import SmtpSettings from "../../../Components/setup&Configuration/smtpSetting/SmtpSettings";

function SmtpSettingsPage(){
  return (
    <>
      <SmtpSettings/>
    </>
  )
}
export default SmtpSettingsPage;