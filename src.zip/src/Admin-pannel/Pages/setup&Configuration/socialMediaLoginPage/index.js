function SocialMediaLoginPage() {
    return (
        <>
            hello social media login page
        </>
    )
}
export default SocialMediaLoginPage;