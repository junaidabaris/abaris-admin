import SetOtpCredential from "../../Components/setOtpCredential/SetOtpCredential";

function SetOtpCredentialPage() {
    return (
        <>
            <SetOtpCredential />
        </>
    )
}
export default SetOtpCredentialPage;