import SupportTicketDetail from "../../Components/supportTicketDetail/SupportTicketDetail";

function SupportTicketDetailPage() {
    return (
        <>
            <SupportTicketDetail />
        </>
    )
}
export default SupportTicketDetailPage;