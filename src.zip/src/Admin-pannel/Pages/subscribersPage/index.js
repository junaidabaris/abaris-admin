import Subscribers from "../../Components/subscribers/Subscribers";

function SubscribersPage() {
    return (
        <>
            <Subscribers />
        </>
    )
}
export default SubscribersPage;