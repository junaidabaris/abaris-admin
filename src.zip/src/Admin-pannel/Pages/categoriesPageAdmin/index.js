import CategoriesAdmin from "../../Components/categories/CategoriesAdmin";

function CategoriesPageAdmin() {
    return (
        <>
            <CategoriesAdmin />
        </>
    )
}
export default CategoriesPageAdmin;