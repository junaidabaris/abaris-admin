import PayoutRequest from "../../Components/payoutRequest/PayoutRequest"

function PayoutRequestPage() {
    return(
        <>
        <PayoutRequest/>
        </>
    )
}
export default PayoutRequestPage