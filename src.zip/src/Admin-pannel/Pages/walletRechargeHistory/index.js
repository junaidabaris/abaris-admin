import WalletRechargeHistory from "../../Components/walletRechargeHistory/WalletRechargeHistory";

function WalletRechargeHistoryPage() {
    return (
        <>
            <WalletRechargeHistory />
        </>
    )
}
export default WalletRechargeHistoryPage;