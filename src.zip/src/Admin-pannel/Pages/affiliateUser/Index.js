import AffiliateUser from "../../Components/affliateUser/AffiliateUser"

function AffiliateUserPage() {
    return (
        <>
        <AffiliateUser/>
        </>
    )
}
export default AffiliateUserPage