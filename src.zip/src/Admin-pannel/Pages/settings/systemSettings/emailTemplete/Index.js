import EmailTempelte from "../../../../Components/settings/emailTemplete/EmailTemplete"

function EmailTempletePage () {
    return (
        <>
        <EmailTempelte/>
        </>
    )
}
export default EmailTempletePage