import SystemSettings from "../../../Components/settings/systemSettings/SystemSettings"

function SystemSettingsPage () {
    return (
        <>
        <SystemSettings/>
        </>
    )
}
export default SystemSettingsPage