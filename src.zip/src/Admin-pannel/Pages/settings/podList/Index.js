import PodList from "../../../Components/settings/podList/PodList"

function PodListPage () {
    return (
        <>
        <PodList/>
        </>
    )
}
export default PodListPage