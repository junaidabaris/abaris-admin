import OfficialSell from "../../../Components/settings/officialSell/OfficialSell"

function OfficialSalePage () {
    return (
        <>
        <OfficialSell/>
        </>
    )
}
export default OfficialSalePage