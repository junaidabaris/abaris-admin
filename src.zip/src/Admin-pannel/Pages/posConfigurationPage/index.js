import PosConfigurationAdmin from "../../Components/posConfigurationAdmin/PosConfigurationAdmin";

function PosConfigurationPage() {
    return (
        <>
           <PosConfigurationAdmin />
        </>
    )
}
export default PosConfigurationPage;