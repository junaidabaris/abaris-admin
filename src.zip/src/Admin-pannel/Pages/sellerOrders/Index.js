import SellerOrder from "../../Components/sellerOrder/SellerOrder"

function SellerOrdersPage(){
    return (
        <>
        <SellerOrder/>
        </>
    )
}
export default SellerOrdersPage