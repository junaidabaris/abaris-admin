import PaymentMethod from "../../Components/paymentMethod/PaymentMethod";

function PaymentMethodPage() {
    return (
        <>
            <PaymentMethod />
        </>
    )
}
export default PaymentMethodPage;