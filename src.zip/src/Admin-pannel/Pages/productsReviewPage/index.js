import ProductsReview from "../../Components/productsReview/ProductsReview";

function ProductsReviewPage() {
    return (
        <>
            <ProductsReview />
        </>
    )
}
export default ProductsReviewPage;