import BulkSMS from "../../Components/bulkSMS/BulkSMS";

function BulkSMSPage() {
    return (
        <>
           <BulkSMS />
        </>
    )
}
export default BulkSMSPage;