import RefferalUsers from "../../Components/refferalUsers/RefferalUser"

function RefferalUsersPage() {
    return (
        <>
        <RefferalUsers/>
        </>
    )
}
export default RefferalUsersPage