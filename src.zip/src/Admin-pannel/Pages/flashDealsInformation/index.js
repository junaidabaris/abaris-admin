import FlashDealInformation from "../../Components/flashDealInformation/FlashDealInformation";

function FlashDealsInformationPage() {
    return (
        <>
            <FlashDealInformation />
        </>
    )
}
export default FlashDealsInformationPage;