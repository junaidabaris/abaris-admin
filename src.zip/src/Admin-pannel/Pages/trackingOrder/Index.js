import TrackingOrder from "../../Components/trackingOrder/TrackingOrder"

function TrackingOrderPage () {
    return (
        <>
        <TrackingOrder/>
        </>
    )
}
export default TrackingOrderPage