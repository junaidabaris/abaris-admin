import Payouts from "../../Components/payout/Payouts"

function PayoutsPage() {
    return (
        <>
        <Payouts/>
        </>
    )
}
export default PayoutsPage