import NewsLetter from "../../Components/newsLetter/NewsLetter";

function NewsLetterPage() {
    return (
        <>
            <NewsLetter />
        </>
    )
}
export default NewsLetterPage;