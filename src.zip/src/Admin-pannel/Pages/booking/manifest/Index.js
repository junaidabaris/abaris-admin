import Manifest from "../../../Components/booking/manifest/Manifest"

function ManifestPage () {
    return (
        <>
        <Manifest/>
        </>
    )
}
export default ManifestPage