import AllSeller from "../../Components/allSeller/AllSeller"

function AllSellerPage() {
    return (
        <>
        <AllSeller/>
        </>
    )
}
export default AllSellerPage