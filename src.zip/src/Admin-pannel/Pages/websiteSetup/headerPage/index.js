import HeaderComp from "../../../Components/websiteSetup/headerComp/HeaderComp";

function HeaderPage() {
    return (
        <>
            <HeaderComp />
        </>
    )
}
export default HeaderPage;