import AddNewPagesComp from "../../../Components/websiteSetup/websitePage/AddNewPages";

function AddNewPage() {
    return (
        <>
            <AddNewPagesComp />
        </>
    )
}
export default AddNewPage;