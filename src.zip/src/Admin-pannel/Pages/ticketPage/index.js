import SupportTicketDesk from "../../Components/supportTicketDesk/SupportTicketDesk";

function TicketPage() {
    return (
        <>
            <SupportTicketDesk />
        </>
    )
}
export default TicketPage;