import AllPost from "../../Components/all-post/AllPost";
function AllPostPage(){
  return(
    <>
      <AllPost/>
    </>
  )
}
export default AllPostPage;