import AppTranslation from "../../Components/appTranslation/AppTranslation";

function AppTranslationPage() {
    return (
        <>
            <AppTranslation />
        </>
    )
}
export default AppTranslationPage;