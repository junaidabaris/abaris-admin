import ServerStatus from "../../Components/serverStatus/ServerStatus";

function ServerStatusPage(){
  return (
    <>
      <ServerStatus/>
    </>
  )
}
export default ServerStatusPage;