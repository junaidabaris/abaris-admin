import SmsTemplates from "../../Components/smsTemplates/SmsTemplates";

function SmsTemplatesPage() {
    return (
        <>
            <SmsTemplates />
        </>
    )
}
export default SmsTemplatesPage;