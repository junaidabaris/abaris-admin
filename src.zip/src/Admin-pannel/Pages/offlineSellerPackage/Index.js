import OfflineSellerPackagePaymentRequest from "../../Components/offlineSellerPackage/OfflineSellerPackagePaymentRequest"

function OfflineSellerPackagePaymentRequestPage(){
    return (
        <>
        <OfflineSellerPackagePaymentRequest/>
        </>
    )
}
export default OfflineSellerPackagePaymentRequestPage