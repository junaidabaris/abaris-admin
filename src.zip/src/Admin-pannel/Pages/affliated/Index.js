import AffiliateForm from "../../Components/AffiliatedForm/AffiliatedForm"

function AffiliatePage() {
    return (
        <>
        <AffiliateForm/>
        </>
    )
}
export default AffiliatePage