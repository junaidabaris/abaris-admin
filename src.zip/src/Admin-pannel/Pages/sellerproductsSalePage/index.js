import SellerProductsSale from "../../Components/sellerProductsSale/SellerProductsSale";

function SellerProductsSalePage() {
    return (
        <>
            <SellerProductsSale />
        </>
    )
}
export default SellerProductsSalePage;