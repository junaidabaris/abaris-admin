import React from 'react'
import AddmetalTypeComp from '../addMetalTypeComp/AddmetalTypeComp'

function EditMetalTypeComp() {
    return (
        <>
            <AddmetalTypeComp />
        </>
    )
}

export default EditMetalTypeComp