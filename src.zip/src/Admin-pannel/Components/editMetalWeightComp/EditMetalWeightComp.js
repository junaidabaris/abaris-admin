import React from 'react'
import AddMetalWeightComp from '../addMetalWeightComp/AddMetalWeightComp'

function EditMetalWeightComp() {
    return (
        <>
            <AddMetalWeightComp />
        </>
    )
}

export default EditMetalWeightComp