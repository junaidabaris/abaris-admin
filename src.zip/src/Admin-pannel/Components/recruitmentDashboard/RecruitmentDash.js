import React from "react";
function RecruitmentDash(){
    return(
        <>
        handl</>
    )
}
export default RecruitmentDash;