import React from 'react'
import AddDiamondClarityPage from '../../../../Pages/jewellery/diamond/addDiamondClarity'

function EditDiamondClarity() {
    return (
        <>
            <AddDiamondClarityPage />
        </>
    )
}

export default EditDiamondClarity