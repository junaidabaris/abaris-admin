import React from 'react'
import AddLabourChargeComp from '../addLbourChargeComp/AddLabourChargeComp'

function EditLabourChargeComp() {
    return (
        <>
            <AddLabourChargeComp />
        </>
    )
}

export default EditLabourChargeComp