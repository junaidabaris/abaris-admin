import React from "react";
import Remindercrm from "../../components/reminder/Remindercrm";
function Reminder(){
    return(
        <>
        <Remindercrm/>
        </>
    )
}
export default Reminder