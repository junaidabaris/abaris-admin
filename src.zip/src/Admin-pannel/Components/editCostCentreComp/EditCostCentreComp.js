import React from 'react'
import CreateCostCentreComp from '../createCostCentreComp/CreateCostCentreComp'

function EditCostCentreComp() {
    return (
        <>
            <CreateCostCentreComp />
        </>
    )
}

export default EditCostCentreComp