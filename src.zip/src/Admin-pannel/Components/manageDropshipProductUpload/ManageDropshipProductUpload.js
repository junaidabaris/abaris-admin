import React from "react";
function ManageDropshipProductUpload(){
    return(
        <>
        hey
        </>
    )
}
export default ManageDropshipProductUpload