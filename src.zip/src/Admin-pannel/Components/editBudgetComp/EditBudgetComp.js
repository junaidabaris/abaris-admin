import React from 'react'
import CreateBudgetComp from '../createBudgetComp/CreateBudgetComp'

function EditBudgetComp() {
    return (
        <>
            <CreateBudgetComp />
        </>
    )
}

export default EditBudgetComp
