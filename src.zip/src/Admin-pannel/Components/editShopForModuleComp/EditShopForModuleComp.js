import React from 'react'
import AddShopForModule from '../generalMaster/shopForModule/addShopForModule/AddShopForModule'

function EditShopForModuleComp() {
    return (
        <>
            <AddShopForModule />
        </>
    )
}

export default EditShopForModuleComp