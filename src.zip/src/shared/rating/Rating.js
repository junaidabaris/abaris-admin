import React from "react";
import {AiFillStar} from "react-icons/ai"
function Rating() {
  return (
    <>
      <div className="rating">
        <AiFillStar />
        <AiFillStar />
        <AiFillStar />
        <AiFillStar />
      </div>
    </>
  );
}

export default Rating;
