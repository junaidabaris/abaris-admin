import OrderDetails from "../../Components/orderDetails/OrderDetails"

function OrdersDetailsPage() {
    return (
        <>
        <OrderDetails/>
        </>
    )
}
export default OrdersDetailsPage