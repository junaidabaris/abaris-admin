import AllOrders from "../../Components/allOrders/AllOrders"

function AllOrdersPage () {
    return (
        <>
        <AllOrders/>
        </>
    )
}
export default AllOrdersPage