import ClubPointConfiguration from "../../Components/clubPointConfiguration/ClubPontConfiguration"

function ClubPointConfigurationPage() {
    return (
        <>
        <ClubPointConfiguration/>
        </>
    )
}
export default ClubPointConfigurationPage