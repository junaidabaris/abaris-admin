import React from 'react'

function SalesTaxReport() {
    return (
        <div>salesTaxReport</div>
    )
}

export default SalesTaxReport