import ComissionHistory from "../../Components/comissionHistory/ComissionHistory";

function ComissionHistoryPage() {
    return (
        <>
            <ComissionHistory />
        </>
    )
}
export default ComissionHistoryPage;