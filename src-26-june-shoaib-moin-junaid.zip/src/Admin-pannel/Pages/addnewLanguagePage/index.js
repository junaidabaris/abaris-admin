import AddNewLanguage from "../../Components/addNewLanguage/AddNewLanguage";

function AddNewLanguagePage() {
    return (
        <>
            <AddNewLanguage />
        </>
    )
}
export default AddNewLanguagePage;