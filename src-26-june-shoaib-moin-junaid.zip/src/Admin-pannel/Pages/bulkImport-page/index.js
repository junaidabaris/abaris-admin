import BulkImport from "../../Components/bulk-import/BulkImport";

function BulkImportPage() {
  return (
    <>
      <BulkImport/>
    </>
  )
}
export default BulkImportPage;