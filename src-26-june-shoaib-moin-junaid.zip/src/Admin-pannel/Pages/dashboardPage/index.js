import DashboardAdminComp from "../../Components/dashboard/Dashboard"

function DashboardAdminPage() {
    return (
        <>
            <DashboardAdminComp />
        </>
    )
}
export default DashboardAdminPage