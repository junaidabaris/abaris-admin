import LanguageTranslation from "../../Components/languageTranslation/LanguageTranslation";

function LanguageTranslationPage() {
    return (
        <>
            <LanguageTranslation />
        </>
    )
}
export default LanguageTranslationPage;