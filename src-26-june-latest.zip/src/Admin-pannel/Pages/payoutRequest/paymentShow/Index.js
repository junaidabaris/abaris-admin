import PaymentShow from "../../../Components/payoutRequest/paymentShow/PaymentShow"

function PaymentShowPage() {
    return (
        <>
        <PaymentShow/>
        </>
    )
}
export default PaymentShowPage