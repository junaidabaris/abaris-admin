import DeliveryRunSheet from "../../../Components/booking/deliveryRunSheet/DeliveryRunSheet"

function DeliveryRunSheetPage () {
    return (
        <>
        <DeliveryRunSheet/>
        </>
    )
}
export default DeliveryRunSheetPage