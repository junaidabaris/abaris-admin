
function ParcleScanPage() {
    return (
        <>
        ParcleScan
        </>
    )
}
export default ParcleScanPage