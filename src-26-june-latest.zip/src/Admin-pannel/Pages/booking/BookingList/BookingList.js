import BookingList from "../../../Components/booking/BookingList/BookingList"

function BookingListPage () {
    return (
        <>
        <BookingList/>
        </>
    )
}
export default BookingListPage