import BookingEntry from "../../../Components/booking/bookingEntry/BookingEntry"

function BookingEntryPage () {
    return (
        <>
        <BookingEntry/>
        </>
    )
}
export default BookingEntryPage