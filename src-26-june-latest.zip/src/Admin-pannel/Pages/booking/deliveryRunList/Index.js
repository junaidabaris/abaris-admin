import DeliveryRunList from "../../../Components/booking/deliveryRunList/DeliveryRunList"

function DeliveryRunListPage () {
    return (
        <>
        <DeliveryRunList/>
        </>
    )
}
export default DeliveryRunListPage