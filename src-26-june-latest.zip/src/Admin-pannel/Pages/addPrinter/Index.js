import AddPrinter from "../../Components/addPrinter/AddPrinter"

function AddPrinterPage () {
    return (
        <>
        <AddPrinter/>
        </>
    )
}
export default AddPrinterPage