import ListPopUp from "../../Components/listPopUp/ListPopUp"

function ListPopUpPage () {
    return (
        <>
       <ListPopUp/>
        </>
    )
}
export default ListPopUpPage