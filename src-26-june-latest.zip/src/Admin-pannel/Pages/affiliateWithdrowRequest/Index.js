import AffiliateWithdrowRequest from "../../Components/affiliateWithdrowRequest/AffiliateWithdrowRequest"

function AffiliateWithdrowPage () {
    return (
        <>
        <AffiliateWithdrowRequest/>
        </>
    )
}
export default AffiliateWithdrowPage