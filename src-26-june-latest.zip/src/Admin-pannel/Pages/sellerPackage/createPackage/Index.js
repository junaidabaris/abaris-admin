import CreatePackage from "../../../Components/sellerPackage/createPackage/CreatePackage"

function CreatePackagePage() {
    return (
        <>
        <CreatePackage/>
        </>
    )
}
export default CreatePackagePage