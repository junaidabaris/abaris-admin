import BlogCategories from "../../Components/blogCategories/BlogCategories";

function BlogCategoriesPage(){
  return(
    <>
      <BlogCategories/>  
    </>
  )
}
export default BlogCategoriesPage;